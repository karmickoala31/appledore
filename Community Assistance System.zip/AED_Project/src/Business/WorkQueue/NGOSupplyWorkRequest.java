/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Distributor.Supply;

/**
 *
 * @author mruke
 */
public class NGOSupplyWorkRequest extends WorkRequest {
    
    
    private int quantity;
    private boolean add;
    private String rtype;
    private String req;
   
    
    

    
      public NGOSupplyWorkRequest() {
       
        add = false;
       
    }

    public String getRtype() {
        return rtype;
    }

    public void setRtype(String rtype) {
        this.rtype = rtype;
    }

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

 
      
      

   
   



    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }
    
      
}


















