CREATE DATABASE  IF NOT EXISTS `restaurant_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `restaurant_db`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurant_db
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `Street` varchar(100) NOT NULL,
  `City` varchar(45) NOT NULL,
  `State` char(2) NOT NULL DEFAULT 'MA',
  `Zipcode` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (101,'013 Ohio Pass','Boston','MA',39236),(102,'217 Brickson Park Hill','Boston','MA',2119),(201,'7 Lukken Lane','Boston','MA',92710),(202,'066 Drewry Place','Boston','MA',20546),(203,'082 Mallard Junction','Boston','MA',87190),(301,'11 Novick Drive','Boston','MA',10120),(401,'386 South Avenue','Boston','MA',31205),(402,'010 Colorado Point','Boston','MA',44315),(403,'3011 Swallow Park','Boston','MA',10203),(404,'0143 Pankratz Circle','Boston','MA',10270),(501,'3499 Spenser Crossing','Boston','MA',20430),(502,'88 Birchwood Road','Boston','MA',20456),(503,'298 Ohio Plaza','Boston','MA',94913),(601,'0905 Dottie Lane','Boston','MA',7208),(602,'580 Corscot Drive','Boston','MA',49505),(603,'39 Melrose Trail','Boston','MA',33462),(604,'4927 Russell Trail','Boston','MA',26505),(605,'2 Monterey Terrace','Boston','MA',30328),(606,'83 Canary Road','Boston','MA',55448),(607,'114 Toban Center','Boston','MA',40618),(701,'7294 Drewry Crossing','Boston','MA',89519),(702,'880 Hintze Parkway','Boston','MA',85030),(703,'30 2nd Hill','Boston','MA',33283),(704,'7 Express Court','Boston','MA',99512),(705,'08439 Maryland Parkway','Boston','MA',18514),(801,'8 Onsgard Place','Boston','MA',55590),(802,'0991 Hanover Court','Boston','MA',84115),(803,'38 1st Junction','Boston','MA',95133);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `cashier_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `bill_date` date DEFAULT NULL,
  PRIMARY KEY (`id`,`cashier_id`,`customer_id`),
  KEY `fk_bill_cashier1_idx` (`cashier_id`),
  KEY `fk_bill_customer1_idx` (`customer_id`),
  CONSTRAINT `fk_bill_cashier1` FOREIGN KEY (`cashier_id`) REFERENCES `cashier` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_bill_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9008 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (9001,34.5,2001,5001,'2017-12-07'),(9002,23.85,2001,5002,'2017-12-07'),(9003,45.9,2001,5003,'2017-12-08'),(9004,23,2001,5004,'2017-12-09'),(9005,23.9,2001,5005,'2017-12-09'),(9006,67.8,2001,5006,'2017-12-10'),(9007,43.2,2001,5007,'2017-12-11');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(45) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `cust_tbl_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`manager_id`,`cust_tbl_id`,`customer_id`),
  KEY `fk_booking_manager1_idx` (`manager_id`),
  KEY `fk_booking_cust_tbl1_idx` (`cust_tbl_id`),
  KEY `fk_booking_customer1_idx` (`customer_id`),
  CONSTRAINT `fk_booking_cust_tbl1` FOREIGN KEY (`cust_tbl_id`) REFERENCES `cust_tbl` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_booking_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_booking_manager1` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10007 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (10001,'2017-12-15','13:30',1001,1111,5001),(10002,'2017-12-15','18:00',1001,1112,5002),(10003,'2017-12-17','20:00',1002,1113,5003),(10004,'2017-12-15','15:00',1002,1115,5004),(10005,'2017-12-21','12:00',1003,1115,5005),(10006,'2017-12-25','19:00',1003,1111,5006);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashier`
--

DROP TABLE IF EXISTS `cashier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL DEFAULT 'M',
  `salary` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `joining_date` date NOT NULL,
  `restaurant_name` varchar(100) NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`restaurant_name`,`Address_id`),
  KEY `fk_cashier_restaurant1_idx` (`restaurant_name`),
  KEY `fk_cashier_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_cashier_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cashier_restaurant1` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurant` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2002 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashier`
--

LOCK TABLES `cashier` WRITE;
/*!40000 ALTER TABLE `cashier` DISABLE KEYS */;
INSERT INTO `cashier` VALUES (2001,'Joseph','Tribbiani','M','$200','2384642633','2017-05-12','taste of india',301);
/*!40000 ALTER TABLE `cashier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chef`
--

DROP TABLE IF EXISTS `chef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chef` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL,
  `salary` varchar(45) NOT NULL,
  `specialization` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `joining_date` date NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Address_id`),
  KEY `fk_chef_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_chef_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3005 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chef`
--

LOCK TABLES `chef` WRITE;
/*!40000 ALTER TABLE `chef` DISABLE KEYS */;
INSERT INTO `chef` VALUES (3001,'Vikas','Khanna','M','$3000','North Indian Cuisine','3642386423','2017-05-12',401),(3002,'Dinara','Kasko','F','$4000','Sweet Delicacies and Drinks','9898876155','2017-05-12',402),(3003,'Gordon','Ramsay','M','$6000','Barbeque and Grill','8675641456','2017-05-12',403),(3004,'Sanjeev','Kapoor','M','$3500','Breads','8774456890','2017-05-12',404);
/*!40000 ALTER TABLE `chef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chef_prepares_order`
--

DROP TABLE IF EXISTS `chef_prepares_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chef_prepares_order` (
  `cust_order_id` int(11) NOT NULL,
  `cust_order_manager_id` int(11) NOT NULL,
  `chef_id` int(11) NOT NULL,
  PRIMARY KEY (`cust_order_id`,`cust_order_manager_id`,`chef_id`),
  KEY `fk_cust_order_has_chef_chef1_idx` (`chef_id`),
  KEY `fk_cust_order_has_chef_cust_order1_idx` (`cust_order_id`,`cust_order_manager_id`),
  CONSTRAINT `fk_cust_order_has_chef_chef1` FOREIGN KEY (`chef_id`) REFERENCES `chef` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cust_order_has_chef_cust_order1` FOREIGN KEY (`cust_order_id`, `cust_order_manager_id`) REFERENCES `cust_order` (`id`, `manager_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chef_prepares_order`
--

LOCK TABLES `chef_prepares_order` WRITE;
/*!40000 ALTER TABLE `chef_prepares_order` DISABLE KEYS */;
INSERT INTO `chef_prepares_order` VALUES (7001,1001,3001),(7002,1001,3001),(7003,1002,3001),(7004,1002,3001),(7006,1003,3001),(7007,1002,3001),(7004,1002,3002),(7005,1003,3002),(7006,1003,3002),(7007,1002,3002),(7001,1001,3003),(7004,1002,3003),(7001,1001,3004),(7002,1001,3004),(7004,1002,3004),(7005,1003,3004),(7006,1003,3004),(7007,1002,3004);
/*!40000 ALTER TABLE `chef_prepares_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust_order`
--

DROP TABLE IF EXISTS `cust_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cust_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manager_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_type` enum('onsite','home_del') NOT NULL DEFAULT 'onsite',
  `waiter_id` int(11) NOT NULL,
  `order_date` date DEFAULT NULL,
  PRIMARY KEY (`id`,`manager_id`,`customer_id`,`waiter_id`),
  KEY `fk_cust_order_manager1_idx` (`manager_id`),
  KEY `fk_cust_order_customer1_idx` (`customer_id`),
  KEY `fk_cust_order_waiter1_idx` (`waiter_id`),
  CONSTRAINT `fk_cust_order_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cust_order_manager1` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cust_order_waiter1` FOREIGN KEY (`waiter_id`) REFERENCES `waiter` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7008 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_order`
--

LOCK TABLES `cust_order` WRITE;
/*!40000 ALTER TABLE `cust_order` DISABLE KEYS */;
INSERT INTO `cust_order` VALUES (7001,1001,5001,'onsite',4001,'2017-12-07'),(7002,1001,5002,'onsite',4001,'2017-12-07'),(7003,1002,5003,'onsite',4002,'2017-12-08'),(7004,1002,5004,'onsite',4002,'2017-12-09'),(7005,1003,5005,'onsite',4003,'2017-12-09'),(7006,1003,5006,'onsite',4003,'2017-12-10'),(7007,1002,5007,'home_del',4003,'2017-12-11');
/*!40000 ALTER TABLE `cust_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust_tbl`
--

DROP TABLE IF EXISTS `cust_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cust_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tbl_capacity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1117 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_tbl`
--

LOCK TABLES `cust_tbl` WRITE;
/*!40000 ALTER TABLE `cust_tbl` DISABLE KEYS */;
INSERT INTO `cust_tbl` VALUES (1111,2),(1112,2),(1113,4),(1114,4),(1115,4),(1116,6);
/*!40000 ALTER TABLE `cust_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `cust_type` enum('visit','home') NOT NULL DEFAULT 'visit',
  `Address_id` int(11) NOT NULL,
  `waiter_id` int(11) NOT NULL,
  `gender` char(1) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`Address_id`,`waiter_id`),
  KEY `fk_customer_Address1_idx` (`Address_id`),
  KEY `fk_customer_waiter1_idx` (`waiter_id`),
  CONSTRAINT `fk_customer_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_waiter1` FOREIGN KEY (`waiter_id`) REFERENCES `waiter` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5008 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (5001,'Gauresh','Chavan','gc@gmail.com','visit',601,501,'M','9879821002'),(5002,'Mohit','Ruke','mr@gmail.com','visit',602,501,'M','6456578884'),(5003,'Aditya','Pawar','ap@gmail.com','visit',603,502,'M','1232424234'),(5004,'Mihir','Kulkarni','mk@gmail.com','visit',604,502,'M','7858786878'),(5005,'Aishwarya','Mardhekar','am@gmail.com','visit',605,503,'F','6856787877'),(5006,'Kedar','Mane','mk@gmail.com','visit',606,503,'M','7858567766'),(5007,'Manali','Kambli','@gmail.com','home',607,501,'F','3473824738');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_boy`
--

DROP TABLE IF EXISTS `delivery_boy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_boy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL,
  `salary` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `joining_date` date NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Address_id`),
  KEY `fk_delivery_boy_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_delivery_boy_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8004 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_boy`
--

LOCK TABLES `delivery_boy` WRITE;
/*!40000 ALTER TABLE `delivery_boy` DISABLE KEYS */;
INSERT INTO `delivery_boy` VALUES (8001,'Rohan','Joshi','M','$200','3583533969','2017-05-12',801),(8002,'Tanmay','Bhatt','M','$200','9897865566','2017-05-12',802),(8003,'Gursimran','Khamba','M','$200','9869419966','2017-05-12',803);
/*!40000 ALTER TABLE `delivery_boy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_item`
--

DROP TABLE IF EXISTS `food_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(45) NOT NULL,
  `item_price` varchar(45) NOT NULL,
  `item_type` varchar(45) NOT NULL,
  `item_category` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_item`
--

LOCK TABLES `food_item` WRITE;
/*!40000 ALTER TABLE `food_item` DISABLE KEYS */;
INSERT INTO `food_item` VALUES (1,'5 pc veg pakora','3.95','Veg','Appetizer'),(2,'5 pc chicken fritter','4.50','Non-veg','Appetizer'),(3,'5 pc egg pakora','3.95','Non-veg','Appetizer'),(4,'2 pc veg samosa','3.95','Veg','Appetizer'),(5,'Special mixed platter','10.95','Veg/Non-veg','Appetizer'),(6,'Chicken clear soup','4.95','Non-veg','Soup'),(7,'Hot&sour soup','4.95','Non-veg','Soup'),(8,'Mulligatawny soup','4.95','Veg','Soup'),(9,'Onion salad','0.99','Veg','Salad'),(10,'Mix green salad','6.95','Veg','Salad'),(11,'Kuchumber salad','5.95','Veg','Salad'),(12,'Tandoori roti','2.50','Veg','Bread'),(13,'Tandoori butter roti','3.00','Veg','Bread'),(14,'Tandoori naan','3.50','Veg','Bread'),(15,'Tandoori butter naan','3.75','Veg','Bread'),(16,'Garlic naan','3.50','Veg','Bread'),(17,'Keema paratha','4.00','Veg','Bread'),(18,'Lachha paratha','2.95','Veg','Bread'),(19,'Veg Biryani','12.95','Veg','Rice'),(20,'Chicken Biryani','14.00','Non-Veg','Rice'),(21,'Mutton Biryani','14.95','Non-Veg','Rice'),(22,'Veg Pulao','9.95','Veg','Rice'),(23,'Prawn Biryani','13.95','Veg','Rice'),(24,'32 oz Chicken Meal','24.95','Non-Veg','Family Meal'),(25,'32 oz Vegetable Meal','19.95','Veg','Family Meal'),(26,'32 oz Mutton Meal','26.95','Non-Veg','Family Meal'),(27,'32 oz Shrimp Meal','24.95','Non-Veg','Family Meal'),(28,'Veg Jalfrezi','10.95','Veg','Gravy'),(29,'Veg Kolhapuri','10.95','Veg','Gravy'),(30,'Paneer Makhanwala','10.95','Veg','Gravy'),(31,'Veg Do-pyaza','10.95','Veg','Gravy'),(32,'Veg Lahori','10.95','Veg','Gravy'),(33,'Veg Korma','10.95','Veg','Gravy'),(34,'Malai Kofta','10.95','Veg','Gravy'),(35,'Bhindi Masala','10.95','Veg','Gravy'),(36,'Pindi Chhole','10.95','Veg','Gravy'),(37,'Chicken Tikka Masala','12.95','Non-Veg','Gravy'),(38,'Chicken Rahra','12.95','Non-Veg','Gravy'),(39,'Chicken Saagwala','12.95','Non-Veg','Gravy'),(40,'Chicken Xacuti','12.95','Non-Veg','Gravy'),(41,'Chicken Saltimbocca','12.95','Non-Veg','Gravy'),(42,'Chicken seekh kebab masala','12.95','Non-Veg','Gravy'),(43,'Shrimp curry','12.95','Non-Veg','Gravy'),(44,'4 pc Gulab Jamun','5.25','Veg','Dessert'),(45,'Baileys Basundhi','6.95','Veg','Dessert'),(46,'4 pc Gulab Jamun','5.25','Veg','Dessert'),(47,'Kheer','5.25','Veg','Dessert'),(48,'12 oz Budweiser','4.00','Beer','Beverages'),(49,'12 oz Coors Light','4.00','Beer','Beverages'),(50,'12 oz Bud Light','4.00','Beer','Beverages'),(51,'12 oz Bira','5.00','Beer','Beverages'),(52,'12 oz Kingfisher Lager','5.50','Beer','Beverages'),(54,'12 oz Tuborg','4.00','Beer','Beverages');
/*!40000 ALTER TABLE `food_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger menu_after_delete 
after delete on food_item for each row
BEGIN

insert into menu_audit (deleted_by, deletion_on, item_id, item_name, item_price, item_type, item_category)
values(user(),sysdate(), old.id, old.item_name, old.item_price, old.item_type, old.item_category);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `food_item_has_chef`
--

DROP TABLE IF EXISTS `food_item_has_chef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_item_has_chef` (
  `food_item_id` int(11) NOT NULL,
  `chef_id` int(11) NOT NULL,
  KEY `food_item_id` (`food_item_id`),
  KEY `chef_id` (`chef_id`),
  CONSTRAINT `food_item_has_chef_ibfk_1` FOREIGN KEY (`food_item_id`) REFERENCES `food_item` (`id`),
  CONSTRAINT `food_item_has_chef_ibfk_2` FOREIGN KEY (`chef_id`) REFERENCES `chef` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_item_has_chef`
--

LOCK TABLES `food_item_has_chef` WRITE;
/*!40000 ALTER TABLE `food_item_has_chef` DISABLE KEYS */;
INSERT INTO `food_item_has_chef` VALUES (1,3003),(2,3003),(3,3003),(4,3003),(5,3003),(6,3003),(7,3003),(8,3003),(9,3003),(10,3003),(11,3003),(12,3003),(13,3004),(14,3004),(15,3004),(16,3004),(17,3004),(18,3004),(19,3001),(20,3001),(21,3001),(22,3001),(23,3001),(24,3001),(25,3001),(26,3001),(27,3001),(28,3001),(29,3001),(30,3001),(31,3001),(32,3001),(33,3001),(34,3001),(35,3001),(36,3001),(37,3001),(38,3001),(39,3001),(40,3001),(41,3001),(42,3001),(43,3001),(44,3002),(45,3002),(46,3002),(47,3002),(48,3002),(49,3002),(50,3002),(51,3002),(52,3002),(54,3002);
/*!40000 ALTER TABLE `food_item_has_chef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_delivery`
--

DROP TABLE IF EXISTS `home_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_name` varchar(100) NOT NULL DEFAULT 'taste of india',
  `bill_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`restaurant_name`,`bill_id`),
  KEY `fk_home_delivery_restaurant1_idx` (`restaurant_name`),
  KEY `fk_home_delivery_bill1_idx` (`bill_id`),
  CONSTRAINT `fk_home_delivery_bill1` FOREIGN KEY (`bill_id`) REFERENCES `bill` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_home_delivery_restaurant1` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurant` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_delivery`
--

LOCK TABLES `home_delivery` WRITE;
/*!40000 ALTER TABLE `home_delivery` DISABLE KEYS */;
INSERT INTO `home_delivery` VALUES (51,'taste of india',9007);
/*!40000 ALTER TABLE `home_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_delivery_has_delivery_boy`
--

DROP TABLE IF EXISTS `home_delivery_has_delivery_boy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_delivery_has_delivery_boy` (
  `home_delivery_id` int(11) NOT NULL,
  `delivery_boy_id` int(11) NOT NULL,
  PRIMARY KEY (`home_delivery_id`,`delivery_boy_id`),
  KEY `fk_home_delivery_has_delivery_boy_delivery_boy1_idx` (`delivery_boy_id`),
  KEY `fk_home_delivery_has_delivery_boy_home_delivery1_idx` (`home_delivery_id`),
  CONSTRAINT `fk_home_delivery_has_delivery_boy_delivery_boy1` FOREIGN KEY (`delivery_boy_id`) REFERENCES `delivery_boy` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_home_delivery_has_delivery_boy_home_delivery1` FOREIGN KEY (`home_delivery_id`) REFERENCES `home_delivery` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_delivery_has_delivery_boy`
--

LOCK TABLES `home_delivery_has_delivery_boy` WRITE;
/*!40000 ALTER TABLE `home_delivery_has_delivery_boy` DISABLE KEYS */;
INSERT INTO `home_delivery_has_delivery_boy` VALUES (51,8001);
/*!40000 ALTER TABLE `home_delivery_has_delivery_boy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `inv_view`
--

DROP TABLE IF EXISTS `inv_view`;
/*!50001 DROP VIEW IF EXISTS `inv_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `inv_view` AS SELECT 
 1 AS `Ing_ID`,
 1 AS `Ing_name`,
 1 AS `Qty`,
 1 AS `Supplier`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `ingredient_id` int(11) NOT NULL AUTO_INCREMENT,
  `ing_name` varchar(45) NOT NULL,
  `quantity` int(11) NOT NULL,
  `ing_type` varchar(45) NOT NULL,
  `restaurant_name` varchar(100) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `rest_owner` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ingredient_id`,`restaurant_name`,`supplier_id`),
  KEY `fk_inventory_restaurant1_idx` (`restaurant_name`),
  KEY `fk_inventory_supplier1_idx` (`supplier_id`),
  CONSTRAINT `fk_inventory_restaurant1` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurant` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_inventory_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'5 pc Chicken Tenders',100,'Poultry','taste of india',6001,'Prakash'),(2,'2 pc Chicken Breasts',100,'Poultry','taste of india',6001,'Prakash'),(3,'32-egg crate',200,'Poultry','taste of india',6001,'Prakash'),(4,'Cauliflower',100,'Vegetable','taste of india',6002,'Prakash'),(5,'Okra',400,'Vegetable','taste of india',6002,'Prakash'),(6,'French Beans',500,'Vegetable','taste of india',6002,'Prakash'),(7,'Roma Tomatoes',500,'Vegetable','taste of india',6002,'Prakash'),(8,'Onions',2000,'Vegetable','taste of india',6002,'Prakash'),(9,'Potatoes',2000,'Vegetable','taste of india',6002,'Prakash'),(10,'Red Chilli powder',100,'Spices','taste of india',6003,'Raman'),(11,'Turmeric powder',100,'Spices','taste of india',6003,'Raman'),(12,'Coriander powder',100,'Spices','taste of india',6003,'Raman'),(13,'Salt',200,'Spices','taste of india',6003,'Raman'),(14,'Green Chilli powder',100,'Spices','taste of india',6003,'Raman'),(15,'All spice powder',100,'Spices','taste of india',6003,'Raman'),(16,'Garam Masala powder',100,'Spices','taste of india',6003,'Raman'),(17,'Rice Flour',100,'Flour','taste of india',6004,'Raman'),(18,'Dosa mix',100,'Spices','taste of india',6004,'Raman'),(19,'Idli mix',100,'Spices','taste of india',6004,'Raman'),(20,'Corn Flour',100,'Spices','taste of india',6004,'Raman'),(21,'Chickpea Flour',100,'Spices','taste of india',6004,'Raman'),(22,'Full fat milk',100,'Spices','taste of india',6005,'Prakash'),(23,'2% fat milk',100,'Spices','taste of india',6005,'Prakash'),(24,'Skimmed milk',100,'Spices','taste of india',6005,'Prakash'),(25,'Paneer',250,'Spices','taste of india',6005,'Prakash'),(26,'Cheddar cheese',100,'Spices','taste of india',6005,'Prakash'),(27,'Parmesan',150,'Spices','taste of india',6005,'Prakash'),(28,'Mozarella',100,'Spices','taste of india',6005,'Prakash'),(29,'Salted butter',400,'Spices','taste of india',6005,'Prakash');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER tr_inv_before_insert
  BEFORE INSERT
  ON inventory
  FOR EACH ROW
BEGIN
    SET NEW.rest_owner = substring_index(user(), '@', 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER tr_inv_before_update
  BEFORE UPDATE
  ON inventory
  FOR EACH ROW
BEGIN
    SET NEW.rest_owner = SUBSTRING_INDEX(user(), '@', 1);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `inventory_check`
--

DROP TABLE IF EXISTS `inventory_check`;
/*!50001 DROP VIEW IF EXISTS `inventory_check`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `inventory_check` AS SELECT 
 1 AS `ID`,
 1 AS `Ingredient`,
 1 AS `Type`,
 1 AS `Qty_in_kg`,
 1 AS `Taken_from`,
 1 AS `Taken_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL,
  `salary` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `joining_date` date NOT NULL,
  `restaurant_name` varchar(100) NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`restaurant_name`,`Address_id`),
  KEY `fk_manager_restaurant_idx` (`restaurant_name`),
  KEY `fk_manager_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_manager_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_manager_restaurant` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurant` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES (1001,'John','Statham','M','$200','2347234236','2017-05-12','taste of india',201),(1002,'Alex','Woodward','M','$220','5464678453','2017-05-12','taste of india',202),(1003,'Riya','Thorpe','F','$250','3412463546','2017-05-12','taste of india',203);
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager_tells_chef`
--

DROP TABLE IF EXISTS `manager_tells_chef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager_tells_chef` (
  `manager_id` int(11) NOT NULL,
  `chef_id` int(11) NOT NULL,
  PRIMARY KEY (`manager_id`,`chef_id`),
  KEY `fk_manager_has_chef_chef1_idx` (`chef_id`),
  KEY `fk_manager_has_chef_manager1_idx` (`manager_id`),
  CONSTRAINT `fk_manager_has_chef_chef1` FOREIGN KEY (`chef_id`) REFERENCES `chef` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_manager_has_chef_manager1` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager_tells_chef`
--

LOCK TABLES `manager_tells_chef` WRITE;
/*!40000 ALTER TABLE `manager_tells_chef` DISABLE KEYS */;
INSERT INTO `manager_tells_chef` VALUES (1001,3001),(1002,3001),(1003,3001),(1002,3002),(1003,3002),(1001,3003),(1002,3003),(1001,3004),(1002,3004),(1003,3004);
/*!40000 ALTER TABLE `manager_tells_chef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_audit`
--

DROP TABLE IF EXISTS `menu_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_audit` (
  `deleted_by` varchar(50) DEFAULT NULL,
  `deletion_on` date DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_name` varchar(45) DEFAULT NULL,
  `item_price` varchar(45) DEFAULT NULL,
  `item_type` varchar(45) DEFAULT NULL,
  `item_category` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_audit`
--

LOCK TABLES `menu_audit` WRITE;
/*!40000 ALTER TABLE `menu_audit` DISABLE KEYS */;
INSERT INTO `menu_audit` VALUES ('chef@localhost','2017-12-12',53,'12 oz Tuborg','4.00','Beer','Beverages');
/*!40000 ALTER TABLE `menu_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_has_food_item`
--

DROP TABLE IF EXISTS `order_has_food_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_has_food_item` (
  `cust_order_id` int(11) NOT NULL,
  `food_item_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`cust_order_id`,`food_item_id`),
  KEY `fk_cust_order_has_food_item_food_item1_idx` (`food_item_id`),
  KEY `fk_cust_order_has_food_item_cust_order1_idx` (`cust_order_id`),
  CONSTRAINT `fk_cust_order_has_food_item_cust_order1` FOREIGN KEY (`cust_order_id`) REFERENCES `cust_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cust_order_has_food_item_food_item1` FOREIGN KEY (`food_item_id`) REFERENCES `food_item` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_has_food_item`
--

LOCK TABLES `order_has_food_item` WRITE;
/*!40000 ALTER TABLE `order_has_food_item` DISABLE KEYS */;
INSERT INTO `order_has_food_item` VALUES (7001,2,1),(7001,29,3),(7002,14,2),(7002,35,1),(7003,20,1),(7004,1,3),(7004,30,1),(7004,52,4),(7005,48,2),(7006,12,3),(7006,43,1),(7006,45,1),(7007,12,5),(7007,37,1),(7007,46,1);
/*!40000 ALTER TABLE `order_has_food_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rest_owner`
--

DROP TABLE IF EXISTS `rest_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rest_owner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `restaurant_name` varchar(100) NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`restaurant_name`,`Address_id`),
  KEY `fk_rest_owner_restaurant1_idx` (`restaurant_name`),
  KEY `fk_rest_owner_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_rest_owner_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_rest_owner_restaurant1` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurant` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rest_owner`
--

LOCK TABLES `rest_owner` WRITE;
/*!40000 ALTER TABLE `rest_owner` DISABLE KEYS */;
INSERT INTO `rest_owner` VALUES (1,'Prakash','Raj','8734263389','taste of india',101),(2,'Raman','Raj','8734263389','taste of india',102);
/*!40000 ALTER TABLE `rest_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant` (
  `name` varchar(100) NOT NULL DEFAULT 'Taste of India',
  `location` varchar(100) NOT NULL DEFAULT '232, Huntington Avenue',
  `open_close_time` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `details` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` VALUES ('Taste of India','232, Huntington Avenue','11:00 - 22:00','8763348993','Restaurant offering an array of indian cuisine');
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `saleperorder`
--

DROP TABLE IF EXISTS `saleperorder`;
/*!50001 DROP VIEW IF EXISTS `saleperorder`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `saleperorder` AS SELECT 
 1 AS `Order_ID`,
 1 AS `Placed_By`,
 1 AS `Total_Amount`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `details` varchar(100) NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Address_id`),
  KEY `fk_supplier_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_supplier_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6006 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (6001,'Mayflower Poultry','6175479191','Provides eggs and chicken',701),(6002,'Costa fruit & Produce','6172418001','Provides vegetables',702),(6003,'Singh Spices','6178972213','Provides essential ground spices and oils',703),(6004,'King Arthur Flour','6179905543','Provides top quality flours',704),(6005,'Makhan Dairy','6175437006','Provides milk, paneer and cheese',705);
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waiter`
--

DROP TABLE IF EXISTS `waiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `waiter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL DEFAULT 'M',
  `salary` varchar(45) NOT NULL,
  `contact` varchar(45) NOT NULL,
  `joining_date` date NOT NULL,
  `Address_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Address_id`),
  KEY `fk_waiter_Address1_idx` (`Address_id`),
  CONSTRAINT `fk_waiter_Address1` FOREIGN KEY (`Address_id`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4004 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waiter`
--

LOCK TABLES `waiter` WRITE;
/*!40000 ALTER TABLE `waiter` DISABLE KEYS */;
INSERT INTO `waiter` VALUES (4001,'Shekhar','Damodaran','M','$100','4534546677','2017-05-12',501),(4002,'Sapan','Verma','M','$100','9876947866','2017-05-12',502),(4003,'Ismail','Khatri','M','$100','5656857683','2017-05-12',503);
/*!40000 ALTER TABLE `waiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `waiter_service`
--

DROP TABLE IF EXISTS `waiter_service`;
/*!50001 DROP VIEW IF EXISTS `waiter_service`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `waiter_service` AS SELECT 
 1 AS `Order_ID`,
 1 AS `waiter`,
 1 AS `Taken_from`,
 1 AS `Delivered_to`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'restaurant_db'
--

--
-- Dumping routines for database 'restaurant_db'
--
/*!50003 DROP PROCEDURE IF EXISTS `bookingProc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `bookingProc`()
BEGIN

select booking.id as Booking_ID, booking.date as Booking_for, booking.time as Booking_at, manager.fname as Taken_by,
 cust_tbl.id as Table_no, cust_tbl.tbl_capacity as Table_capacity
from manager inner join booking on manager.id = booking.manager_id 
inner join cust_tbl on booking.cust_tbl_id = cust_tbl.id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `suppListProc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `suppListProc`(in sup_id int)
BEGIN 

select supplier.id as Supplier_ID ,supplier.supplier_name as Supplier_Name, inventory.ingredient_id as Ing_ID,
inventory.ing_name as Ing_name, inventory.quantity as Quantity
from supplier inner join inventory on supplier.id = inventory.supplier_id
where supplier_id = sup_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `inv_view`
--

/*!50001 DROP VIEW IF EXISTS `inv_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `inv_view` AS select `inventory`.`ingredient_id` AS `Ing_ID`,`inventory`.`ing_name` AS `Ing_name`,`inventory`.`quantity` AS `Qty`,`inventory`.`supplier_id` AS `Supplier` from `inventory` where (`inventory`.`rest_owner` = substring_index(user(),'@',1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `inventory_check`
--

/*!50001 DROP VIEW IF EXISTS `inventory_check`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `inventory_check` AS select `inventory`.`ingredient_id` AS `ID`,`inventory`.`ing_name` AS `Ingredient`,`inventory`.`ing_type` AS `Type`,`inventory`.`quantity` AS `Qty_in_kg`,`supplier`.`supplier_name` AS `Taken_from`,`rest_owner`.`fname` AS `Taken_by` from ((`inventory` left join `supplier` on((`inventory`.`supplier_id` = `supplier`.`id`))) join `rest_owner` on((`inventory`.`rest_owner` = `rest_owner`.`fname`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `saleperorder`
--

/*!50001 DROP VIEW IF EXISTS `saleperorder`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `saleperorder` AS select `cust_order`.`id` AS `Order_ID`,concat_ws(' ',`customer`.`fname`,`customer`.`lname`) AS `Placed_By`,round(sum((`order_has_food_item`.`quantity` * `food_item`.`item_price`)),2) AS `Total_Amount` from (`customer` left join ((`cust_order` join `order_has_food_item` on((`cust_order`.`id` = `order_has_food_item`.`cust_order_id`))) join `food_item` on((`order_has_food_item`.`food_item_id` = `food_item`.`id`))) on((`cust_order`.`customer_id` = `customer`.`id`))) group by `cust_order`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `waiter_service`
--

/*!50001 DROP VIEW IF EXISTS `waiter_service`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `waiter_service` AS select `cust_order`.`id` AS `Order_ID`,concat(' ',`waiter`.`fname`,`waiter`.`lname`) AS `waiter`,`manager`.`fname` AS `Taken_from`,`customer`.`fname` AS `Delivered_to` from (`customer` left join (`manager` left join (`cust_order` join `waiter` on((`cust_order`.`waiter_id` = `waiter`.`id`))) on((`cust_order`.`manager_id` = `manager`.`id`))) on((`cust_order`.`customer_id` = `customer`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-13 21:50:45
