

insert into restaurant value ('Taste of India', '232, Huntington Avenue', '11:00 - 22:00', '8763348993', 'Restaurant offering an array of indian cuisine');
select * from restaurant;

insert into rest_owner (fname,lname,contact,restaurant_name,address_id)value ('Prakash','Raj','8734263389','taste of india',101);
insert into rest_owner (fname,lname,contact,restaurant_name,address_id)value ('Raman','Raj','8734263389','taste of india',102);
select * from rest_owner;

insert into cashier (fname, lname, contact, salary, gender, joining_date, restaurant_name, address_id)
value('Joseph','Tribbiani','2384642633','$200','M','2017/05/12','taste of india',301);
select * from cashier;


alter table manager auto_increment = 1001;
insert into manager (fname, lname, contact, salary, gender, joining_date, restaurant_name, address_id)
values ('John','Statham','2347234236','$200','M','2017/05/12','taste of india',201);
insert into manager (fname, lname, contact, salary, gender, joining_date, restaurant_name, address_id)
values ('Alex','Woodward','5464678453','$220','M','2017/05/12','taste of india',202);
insert into manager (fname, lname, contact, salary, gender, joining_date, restaurant_name, address_id)
values ('Riya','Thorpe','3412463546','$250','F','2017/05/12','taste of india',203);
select * from manager;


alter table booking auto_increment = 10001;
insert into booking (date, time, manager_id, cust_tbl_id,customer_id)
values ('2017/12/15','13:30',1001,1111,5001);
insert into booking (date, time, manager_id, cust_tbl_id,customer_id)
values ('2017/12/15','18:00',1001,1112,5002);
insert into booking (date, time, manager_id, cust_tbl_id,customer_id)
values ('2017/12/17','20:00',1002,1113,5003);
insert into booking (date, time, manager_id, cust_tbl_id,customer_id)
values ('2017/12/15','15:00',1002,1115,5004);
insert into booking (date, time, manager_id, cust_tbl_id,customer_id)
values ('2017/12/21','12:00',1003,1115,5005);
insert into booking (date, time, manager_id, cust_tbl_id,customer_id)
values ('2017/12/25','19:00',1003,1111,5006);
select * from booking;


insert into chef (fname, lname, contact, salary, gender, joining_date, specialization, address_id)
values ('Vikas','Khanna','3642386423','$3000','M','2017/05/12','North Indian Cuisine',401);
insert into chef (fname, lname, contact, salary, gender, joining_date, specialization,address_id)
values ('Dinara','Kasko','9898876155','$4000','F','2017/05/12','Sweet Delicacies',402);
insert into chef (fname, lname, contact, salary, gender, joining_date, specialization,address_id)
values ('Gordon','Ramsay','8675641456','$6000','M','2017/05/12','Barbeque and Grill',403);
insert into chef (fname, lname, contact, salary, gender, joining_date, specialization,address_id)
values ('Sanjeev','Kapoor','8774456890','$3500','M','2017/05/12','South Indian and Maharashtrian cuisine',404);
select * from chef;

insert into manager_tells_chef values(1,1);
insert into manager_tells_chef values(1,2);
insert into manager_tells_chef values(2,4);
insert into manager_tells_chef values(2,2);
insert into manager_tells_chef values(3,3);
select * from manager_tells_chef;

insert into food_item (item_name, item_price, item_type, item_category)
values('5 pc veg pakora', '$3.95','Veg','Appetizer');
insert into food_item (item_name, item_price, item_type, item_category)
values('5 pc chicken fritter', '$4.50','Non-veg','Appetizer');
insert into food_item (item_name, item_price, item_type, item_category)
values('5 pc egg pakora', '$3.95','Non-veg','Appetizer');
insert into food_item (item_name, item_price, item_type, item_category)
values('2 pc veg samosa', '$3.95','Veg','Appetizer');
insert into food_item (item_name, item_price, item_type, item_category)
values('Special mixed platter', '$10.95','Veg/Non-veg','Appetizer');

insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken clear soup', '$4.95','Non-veg','Soup');
insert into food_item (item_name, item_price, item_type, item_category)
values('Hot&sour soup', '$4.95','Non-veg','Soup');
insert into food_item (item_name, item_price, item_type, item_category)
values('Mulligatawny soup', '$4.95','Veg','Soup');

insert into food_item (item_name, item_price, item_type, item_category)
values('Onion salad', '$0.99','Veg','Salad');
insert into food_item (item_name, item_price, item_type, item_category)
values('Mix green salad', '$6.95','Veg','Salad');
insert into food_item (item_name, item_price, item_type, item_category)
values('Kuchumber salad', '$5.95','Veg','Salad');

insert into food_item (item_name, item_price, item_type, item_category)
values('Tandoori roti', '$2.50','Veg','Bread');
insert into food_item (item_name, item_price, item_type, item_category)
values('Tandoori butter roti', '$3.00','Veg','Bread');
insert into food_item (item_name, item_price, item_type, item_category)
values('Tandoori naan', '$3.50','Veg','Bread');
insert into food_item (item_name, item_price, item_type, item_category)
values('Tandoori butter naan', '$3.75','Veg','Bread');
insert into food_item (item_name, item_price, item_type, item_category)
values('Garlic naan', '$3.50','Veg','Bread');
insert into food_item (item_name, item_price, item_type, item_category)
values('Keema paratha', '$4.00','Veg','Bread');
insert into food_item (item_name, item_price, item_type, item_category)
values('Lachha paratha', '$2.95','Veg','Bread');

insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Biryani', '$12.95','Veg','Rice');
insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken Biryani', '$14.00','Non-Veg','Rice');
insert into food_item (item_name, item_price, item_type, item_category)
values('Mutton Biryani', '$14.95','Non-Veg','Rice');
insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Pulao', '$9.95','Veg','Rice');
insert into food_item (item_name, item_price, item_type, item_category)
values('Prawn Biryani', '$13.95','Veg','Rice');


insert into food_item (item_name, item_price, item_type, item_category)
values('32 oz Chicken Meal', '$24.95','Non-Veg','Family Meal');
insert into food_item (item_name, item_price, item_type, item_category)
values('32 oz Vegetable Meal', '$19.95','Veg','Family Meal');
insert into food_item (item_name, item_price, item_type, item_category)
values('32 oz Mutton Meal', '$26.95','Non-Veg','Family Meal');
insert into food_item (item_name, item_price, item_type, item_category)
values('32 oz Shrimp Meal', '$24.95','Non-Veg','Family Meal');

insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Jalfrezi', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Kolhapuri', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Paneer Makhanwala', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Do-pyaza', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Lahori', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Veg Korma', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Malai Kofta', '$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Bhindi Masala','$10.95','Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Pindi Chhole', '$10.95','Veg','Gravy');

insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken Tikka Masala', '$12.95','Non-Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken Rahra', '$12.95','Non-Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken Saagwala', '$12.95','Non-Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken Xacuti', '$12.95','Non-Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken Saltimbocca', '$12.95','Non-Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Chicken seekh kebab masala', '$12.95','Non-Veg','Gravy');
insert into food_item (item_name, item_price, item_type, item_category)
values('Shrimp curry', '$12.95','Non-Veg','Gravy');

insert into food_item (item_name, item_price, item_type, item_category)
values('4 pc Gulab Jamun', '$5.25','Veg','Dessert');
insert into food_item (item_name, item_price, item_type, item_category)
values('Baileys Basundhi', '$6.95','Veg','Dessert');
insert into food_item (item_name, item_price, item_type, item_category)
values('4 pc Gulab Jamun', '$5.25','Veg','Dessert');
insert into food_item (item_name, item_price, item_type, item_category)
values('Kheer', '$5.25','Veg','Dessert');

insert into food_item (item_name, item_price, item_type, item_category)
values('12 oz Budweiser', '$4.00','Beer','Beverages');
insert into food_item (item_name, item_price, item_type, item_category)
values('12 oz Coors Light', '$4.00','Beer','Beverages');
insert into food_item (item_name, item_price, item_type, item_category)
values('12 oz Bud Light', '$4.00','Beer','Beverages');
insert into food_item (item_name, item_price, item_type, item_category)
values('12 oz Bira', '$5.00','Beer','Beverages');
insert into food_item (item_name, item_price, item_type, item_category)
values('12 oz Kingfisher Lager', '$5.50','Beer','Beverages');
insert into food_item (item_name, item_price, item_type, item_category)
values('12 oz Tuborg', '$4.00','Beer','Beverages');
select * from food_item;

alter table waiter auto_increment = 4001;
insert into waiter (fname, lname, contact, salary, gender, joining_date,address_id)
values ('Shekhar','Damodaran','4534546677','$100','M','2017/05/12',501);
insert into waiter (fname, lname, contact, salary, gender, joining_date,address_id)
values ('Sapan','Verma','9876947866','$100','M','2017/05/12',502);
insert into waiter (fname, lname, contact, salary, gender, joining_date,address_id)
values ('Ismail','Khatri','5656857683','$100','M','2017/05/12',503);
select * from waiter;

set foreign_key_checks= 1;

insert into cust_order(manager_id, waiter_id)
values('1','1');
insert into cust_order(manager_id, waiter_id)
values('1','3');
insert into cust_order(manager_id, waiter_id)
values('2','3');
insert into cust_order(manager_id, waiter_id)
values('2','1');
insert into cust_order(manager_id, waiter_id)
values('3','3');
insert into cust_order(manager_id, waiter_id)
values('3','1');

alter table customer auto_increment = 5001;
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Gauresh','Chavan','gc@gmail.com','visit',601,501);
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Mohit','Ruke','mr@gmail.com','visit',602,501);
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Aditya','Pawar','ap@gmail.com','visit',603,502);
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Mihir','Kulkarni','mk@gmail.com','visit',604,502);
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Aishwarya','Mardhekar','am@gmail.com','visit',605,503);
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Kedar','Mane','mk@gmail.com','visit',606,503);
insert into customer (fname,lname,email_id,cust_type,address_id,waiter_id) 
values('Manali','Kambli','@gmail.com','home',607,501);
select * from customer;

alter table supplier auto_increment = 6001;
insert into supplier(supplier_name,contact, details, address_id)
values('Mayflower Poultry','6175479191','Provides eggs and chicken', 701);
insert into supplier(supplier_name,contact, details, address_id)
values('Costa fruit & Produce','6172418001','Provides vegetables', 702);
insert into supplier(supplier_name,contact, details, address_id)
values('Singh Spices','6178972213','Provides essential ground spices and oils', 703);
insert into supplier(supplier_name,contact, details, address_id)
values('King Arthur Flour','6179905543','Provides top quality flours', 704);
insert into supplier(supplier_name,contact, details, address_id)
values('Makhan Dairy','6175437006','Provides milk, paneer and cheese', 705);
select * from supplier;

alter table inventory auto_increment = 001;
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('5 pc Chicken Tenders','100','Poultry','taste of india','6001');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('2 pc Chicken Breasts','100','Poultry','taste of india','6001');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('32-egg crate','200','Poultry','taste of india','6001');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Cauliflower','100','Vegetable','taste of india','6002');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Okra','400','Vegetable','taste of india','6002');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('French Beans','500','Vegetable','taste of india','6002');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Roma Tomatoes','500','Vegetable','taste of india','6002');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Onions','2000','Vegetable','taste of india','6002');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Potatoes','2000','Vegetable','taste of india','6002');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Red Chilli powder','100','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Turmeric powder','100','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Coriander powder','100','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Salt','200','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Green Chilli powder','100','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('All spice powder','100','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Garam Masala powder','100','Spices','taste of india','6003');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Rice Flour','100','Flour','taste of india','6004');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Dosa mix','100','Spices','taste of india','6004');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Idli mix','100','Spices','taste of india','6004');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Corn Flour','100','Spices','taste of india','6004');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Chickpea Flour','100','Spices','taste of india','6004');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Full fat milk','100','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('2% fat milk','100','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Skimmed milk','100','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Paneer','250','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Cheddar cheese','100','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Parmesan','150','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Mozarella','100','Spices','taste of india','6005');
insert into inventory(ing_name, quantity, ing_type, restaurant_name, supplier_id)
values('Salted butter','400','Spices','taste of india','6005');
select * from inventory;

alter table cust_tbl auto_increment = 1111;
insert into cust_tbl (no_of_cust) values(2);
insert into cust_tbl (no_of_cust) values(2);
insert into cust_tbl (no_of_cust) values(4);
insert into cust_tbl (no_of_cust) values(4);
insert into cust_tbl (no_of_cust) values(4);
insert into cust_tbl (no_of_cust) values(6);
select * from cust_tbl;

alter table cust_order auto_increment = 7001;
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1001,5001,'onsite',4001);
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1001,5002,'onsite',4001);
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1002,5003,'onsite',4002);
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1002,5004,'onsite',4002);
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1003,5005,'onsite',4003);
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1003,5006,'onsite',4003);
insert into cust_order (manager_id, customer_id, order_type, waiter_id)
values(1002,5007,'home_del',4003);
select * from cust_order;

insert into order_has_food_item(cust_order_id, food_item_id, quantity)
values(7001,2,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7001,16,'2');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7001,29,'3');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7002,35,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7002,14,'2');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7003,20,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7004,30,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7004,16,'4');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7004,52,'4');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7004,1,'3');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7005,16,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7005,48,'2');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7006,43,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7006,12,'3');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7006,45,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7007,37,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7007,40,'1');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7007,12,'5');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7007,16,'3');
insert into order_has_food_item(cust_order_id, food_item_id,quantity)
values(7007,46,'1');

select * from order_has_food_item;
select * from food_item;
select * from cust_order;
select * from chef;

update chef
set specialization ='Sweet Delicacies and Drinks'
where id=3002;

delete from order_has_food_item
where food_item_id = 40;

insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7001,1001,3003);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7001,1001,3004);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7001,1001,3001);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7002,1001,3004);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7002,1001,3001);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7003,1002,3001);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7004,1002,3003);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7004,1002,3004);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7004,1002,3001);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7004,1002,3002);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7005,1003,3004);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7005,1003,3002);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7006,1003,3004);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7006,1003,3001);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7006,1003,3002);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7007,1002,3004);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7007,1002,3001);
insert into chef_prepares_order(cust_order_id, cust_order_manager_id,chef_id)
values(7007,1002,3002);

select * from chef_prepares_order
order by cust_order_id asc;

alter table delivery_boy auto_increment = 8001;
insert into delivery_boy (fname, lname, contact, salary, gender, joining_date, address_id)
values ('Rohan','Joshi','3583533969','$200','M','2017/05/12',801);
insert into delivery_boy (fname, lname, contact, salary, gender, joining_date, address_id)
values ('Tanmay','Bhatt','9897865566','$200','M','2017/05/12',802);
insert into delivery_boy (fname, lname, contact, salary, gender, joining_date, address_id)
values ('Gursimran','Khamba','9869419966','$200','M','2017/05/12',803);
select * from delivery_boy;

select * from order_has_food_item;

alter table bill auto_increment = 9001;
insert into bill(amount, cashier_id, customer_id) 
values('34.50',2001,5001);
insert into bill(amount, cashier_id, customer_id) 
values('23.85',2001,5002);
insert into bill(amount, cashier_id, customer_id) 
values('45.90',2001,5003);
insert into bill(amount, cashier_id, customer_id) 
values('23.00',2001,5004);
insert into bill(amount, cashier_id, customer_id) 
values('23.90',2001,5005);
insert into bill(amount, cashier_id, customer_id) 
values('67.80',2001,5006);
insert into bill(amount, cashier_id, customer_id) 
values('43.20',2001,5007);
select * from bill;

alter table home_delivery auto_increment = 51;
insert into home_delivery(restaurant_name, bill_id)
value('taste of india',9007);
select * from home_delivery;

insert into home_delivery_has_delivery_boy values(51,801);
select * from home_delivery_has_delivery_boy;

select * from chef;

insert into address(id,street, city, state, zipcode) values (101,'013 Ohio Pass', 'Boston', 'MA', '39236');
insert into address(id,street, city, state, zipcode) values (102,'217 Brickson Park Hill', 'Boston', 'MA', '02119');
insert into address(id,street, city, state, zipcode) values (201,'7 Lukken Lane', 'Boston', 'MA', '92710');
insert into address(id,street, city, state, zipcode) values (202,'066 Drewry Place', 'Boston', 'MA', '20546');
insert into address(id,street, city, state, zipcode) values (203,'082 Mallard Junction', 'Boston', 'MA', '87190');
insert into address(id,street, city, state, zipcode) values (301,'11 Novick Drive', 'Boston', 'MA', '10120');
insert into address(id,street, city, state, zipcode) values (401,'386 South Avenue', 'Boston', 'MA', '31205');
insert into address(id,street, city, state, zipcode) values (402,'010 Colorado Point', 'Boston', 'MA', '44315');
insert into address(id,street, city, state, zipcode) values (403,'3011 Swallow Park', 'Boston', 'MA', '10203');
insert into address(id,street, city, state, zipcode) values (404,'0143 Pankratz Circle', 'Boston', 'MA', '10270');
insert into address(id,street, city, state, zipcode) values (501,'3499 Spenser Crossing', 'Boston', 'MA', '20430');
insert into address(id,street, city, state, zipcode) values (502,'88 Birchwood Road', 'Boston', 'MA', '20456');
insert into address(id,street, city, state, zipcode) values (503,'298 Ohio Plaza', 'Boston', 'MA', '94913');
insert into address(id,street, city, state, zipcode) values (601,'0905 Dottie Lane', 'Boston', 'MA', '07208');
insert into address(id,street, city, state, zipcode) values (602,'580 Corscot Drive', 'Boston', 'MA', '49505');
insert into address(id,street, city, state, zipcode) values (603,'39 Melrose Trail', 'Boston', 'MA', '33462');
insert into address(id,street, city, state, zipcode) values (604,'4927 Russell Trail', 'Boston', 'MA', '26505');
insert into address(id,street, city, state, zipcode) values (605,'2 Monterey Terrace', 'Boston', 'MA', '30328');
insert into address(id,street, city, state, zipcode) values (606,'83 Canary Road', 'Boston', 'MA', '55448');
insert into address(id,street, city, state, zipcode) values (607,'114 Toban Center', 'Boston', 'MA', '40618');
insert into address(id,street, city, state, zipcode) values (701,'7294 Drewry Crossing', 'Boston', 'MA', '89519');
insert into address(id,street, city, state, zipcode) values (702,'880 Hintze Parkway', 'Boston', 'MA', '85030');
insert into address(id,street, city, state, zipcode) values (703,'30 2nd Hill', 'Boston', 'MA', '33283');
insert into address(id,street, city, state, zipcode) values (704,'7 Express Court', 'Boston', 'MA', '99512');
insert into address(id,street, city, state, zipcode) values (705,'08439 Maryland Parkway', 'Boston', 'MA', '18514');
insert into address(id,street, city, state, zipcode) values (801,'8 Onsgard Place', 'Boston', 'MA', '55590');
insert into address(id,street, city, state, zipcode) values (802,'0991 Hanover Court', 'Boston', 'MA', '84115');
insert into address(id,street, city, state, zipcode) values (803,'38 1st Junction', 'Boston', 'MA', '95133');
select * from address;
 
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1001,3003,7001);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1001,3004,7001);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1001,3001,7001);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1001,3004,7002);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1001,3001,7002);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3001,7003);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3003,7004);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3004,7004);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3001,7004);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3002,7004);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1003,3004,7005);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1003,3002,7005);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1003,3004,7006);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1003,3001,7006);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1003,3002,7006);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3004,7007);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3001,7007);
insert into manager_tells_chef(manager_id, chef_id,order_id)
values(1002,3002,7007);
select * from manager_tells_chef;

insert into manager_tells_chef(manager_id, chef_id)
value(1001,3003);
insert into manager_tells_chef(manager_id, chef_id)
value(1001,3004);
insert into manager_tells_chef(manager_id, chef_id)
value(1001,3001);
insert into manager_tells_chef(manager_id, chef_id)
value(1002,3001);
insert into manager_tells_chef(manager_id, chef_id)
value(1002,3002);
insert into manager_tells_chef(manager_id, chef_id)
value(1002,3003);
insert into manager_tells_chef(manager_id, chef_id)
value(1002,3004);
insert into manager_tells_chef(manager_id, chef_id)
value(1003,3001);
insert into manager_tells_chef(manager_id, chef_id)
value(1003,3002);
insert into manager_tells_chef(manager_id, chef_id)
value(1003,3004);

select * from cust_order;

update cust_order
set order_date = '2017/12/11'
where id = 7007;

select * from food_item;
truncate table manager_tells_chef;

alter table cust_order
add column order_date date ;

alter table manager_tells_chef
drop foreign key order_id;

alter table cust_order
add column order_date date;

select * from bill;
select * from cust_order;

update bill 
set bill_date = '2017-12-07'
where customer_id = 5001;
update bill 
set bill_date = '2017-12-07'
where customer_id = 5002;
update bill 
set bill_date = '2017-12-08'
where customer_id = 5003;
update bill 
set bill_date = '2017-12-09'
where customer_id = 5004;
update bill 
set bill_date = '2017-12-09'
where customer_id = 5005;
update bill 
set bill_date = '2017-12-10'
where customer_id = 5006;
update bill 
set bill_date = '2017-12-11'
where customer_id = 5007;
select * from bill;

select *
from cust_order 
left join order_has_food_item as o1
on cust_order.id = o1.cust_order_id
inner join food_item as f1
on o1.food_item_id = f1.id
order by cust_order.id;

-- order history with customer details
select cust_order_id, customer_id, order_type, order_date, item_name, quantity, item_price, round((item_price) * (quantity),2) as total 
from cust_order 
left join order_has_food_item as o1
on cust_order.id = o1.cust_order_id
inner join food_item as f1
on o1.food_item_id = f1.id
order by cust_order.id;

-- customer address details
select customer.id, concat_ws(' ',fname,lname) as Customer_Name, gender, contact, concat_ws(', ',street,city,state,zipcode) as Address
from customer
inner join address
on customer.Address_id = address.id
order by customer.id;

select * from home_delivery;

-- home delivery orders with customer details 
select home_delivery.id, bill_date as Date , concat_ws(' ',fname,lname) as Customer_Name, 
 item_name, quantity, item_price, round(item_price * quantity,2) as Total
from home_delivery inner join bill on home_delivery.bill_id = bill.id
inner join customer on bill.customer_id = customer.id
inner join cust_order on customer.id = cust_order.customer_id
inner join order_has_food_item on cust_order.id = order_has_food_item.cust_order_id
inner join food_item on order_has_food_item.food_item_id = food_item.id;

-- delivery boy details 
select home_delivery.id, delivery_boy.id as Boy_ID, concat_ws(' ',fname,lname) as Boy_Name, contact 
from home_delivery inner join home_delivery_has_delivery_boy
on home_delivery.id = home_delivery_has_delivery_boy.home_delivery_id
inner join delivery_boy on home_delivery_has_delivery_boy.delivery_boy_id = delivery_boy.id;

-- chef catalog
select chef.id, concat_ws(' ',fname,lname) as Chef_Name, chef.specialization ,food_item.item_name
from chef right join food_item_has_chef on chef.id = food_item_has_chef.chef_id
inner join food_item on food_item_has_chef.food_item_id = food_item.id
where chef.id = 3003;
;


select * from chef_prepares_order
order by cust_order_id;
select * from cust_order;
select * from order_has_food_item;

-- manager catalog
select manager.id, concat_ws(' ',manager.fname,manager.lname) as Manager_Name, cust_order.id as Order_ID, customer.id, 
concat_ws(' ',customer.fname,customer.lname) as Customer_Name, cust_order.order_date as Service_Date
from manager inner join cust_order on manager.id = cust_order.manager_id
inner join customer on cust_order.customer_id = customer.id;

-- number of orders serviced by individual managers
select manager.id, concat_ws(' ',manager.fname,manager.lname) as Manager_Name, count(cust_order.id) as Orders_Serviced
from manager inner join cust_order on manager.id = cust_order.manager_id
inner join customer on cust_order.customer_id = customer.id
where manager_id=1002;

-- VIEW: orders taken from manager by waiters and delivered to customers
create view waiter_service as
select cust_order.id as Order_ID, concat(' ', waiter.fname, waiter.lname) as waiter, manager.fname as Taken_from,
customer.fname as Delivered_to 
from cust_order inner join waiter on cust_order.waiter_id = waiter.id
right join manager on cust_order.manager_id = manager.id
right join customer on cust_order.customer_id = customer.id;

select * from waiter_service;

-- VIEW: sale behind every customer order
create view SalePerOrder as
select cust_order.id as Order_ID, concat_ws(' ',customer.fname, customer.lname) as Placed_By, 
round(sum((order_has_food_item.quantity) * (food_item.item_price)), 2) as Total_Amount
from cust_order inner join order_has_food_item on cust_order.id = order_has_food_item.cust_order_id
inner join food_item on order_has_food_item.food_item_id = food_item.id
right join customer on cust_order.customer_id = customer.id
group by cust_order.id ASC;

select * from saleperorder;

-- VIEW : ingredient bought from suppliers and owner responsible for that
create view inventory_check as
select inventory.ingredient_id as ID, inventory.ing_name as Ingredient, inventory.ing_type as Type, inventory.quantity as Qty_in_kg,
supplier.supplier_name as Taken_from, rest_owner.fname as Taken_by
from inventory left join supplier on inventory.supplier_id = supplier.id
inner join rest_owner on inventory.rest_owner = rest_owner.fname;

select * from inventory_check;

-- STORE PROC: booking details
DELIMITER $
create procedure bookingProc()
BEGIN

select booking.id as Booking_ID, booking.date as Booking_for, booking.time as Booking_at, manager.fname as Taken_by,
 cust_tbl.id as Table_no, cust_tbl.tbl_capacity as Table_capacity
from manager inner join booking on manager.id = booking.manager_id 
inner join cust_tbl on booking.cust_tbl_id = cust_tbl.id;

END
$

-- STORE PROC: Supplier information providing all the products
DELIMITER $
create procedure suppListProc(in sup_id int)
BEGIN 

select supplier.id as Supplier_ID ,supplier.supplier_name as Supplier_Name, inventory.ingredient_id as Ing_ID,
inventory.ing_name as Ing_name, inventory.quantity as Quantity
from supplier inner join inventory on supplier.id = inventory.supplier_id
where supplier_id = sup_id;

END
$

-- User created
create user 'chef'@'localhost' identified by 'chef';

-- table for TRIGGER: menu_after_delete
create table menu_audit(
deleted_by varchar(50),
deletion_on date,
item_id int,
item_name varchar(45),
item_price varchar(45),
item_type varchar(45),
item_category varchar(45)
);

-- TRIGGER: back up records deleted from food menu by user chef
DELIMITER $
create trigger menu_after_delete 
after delete on food_item for each row
BEGIN

insert into menu_audit (deleted_by, deletion_on, item_id, item_name, item_price, item_type, item_category)
values(user(),sysdate(), old.id, old.item_name, old.item_price, old.item_type, old.item_category);

END
$

-- ****** ROW LEVEL SECURITY ******
-- Users created (Owners)
create user 'Prakash'@'localhost' identified by 'prakash';
create user 'Raman'@'localhost' identified by 'raman';

-- Priveleges
GRANT all 
ON restaurant_db.inv_view
TO 'Prakash'@'localhost';
 
GRANT all
ON restaurant_db.inv_view
TO 'Raman'@'localhost';

-- VIEW: returns relevant data to each owner
create view inv_view as
select inventory.ingredient_id as Ing_ID, inventory.ing_name as Ing_name, inventory.quantity as Qty, inventory.supplier_id as Supplier
from inventory
where (inventory.rest_owner = substring_index(user(), '@', 1));

select * from inv_view;

-- TRIGGER: to fix a newly added row to its designated owner
DELIMITER $
CREATE TRIGGER tr_inv_before_insert
  BEFORE INSERT
  ON inventory
  FOR EACH ROW
BEGIN
    SET NEW.rest_owner = substring_index(user(), '@', 1);
END
$

-- TRIGGER: to prevent the owner replacement. Trigger activates whenever a row is modified.
DELIMITER $
CREATE TRIGGER tr_inv_before_update
  BEFORE UPDATE
  ON inventory
  FOR EACH ROW
BEGIN
    SET NEW.rest_owner = SUBSTRING_INDEX(user(), '@', 1);
END
$
